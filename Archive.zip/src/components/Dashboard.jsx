import React from 'react';
    import { Chart } from 'chart.js/auto';
    import { useRef, useEffect } from 'react';
    import formatIndianNumber from '../utils/formatIndianNumber';

    function Dashboard({ expenses, transactions }) {
      const expenseChartRef = useRef(null);
      const incomeChartRef = useRef(null);
      const debtChartRef = useRef(null);
      const lendChartRef = useRef(null);

      useEffect(() => {
        if (expenses.length > 0) {
          const descriptionTotals = expenses.reduce((acc, expense) => {
            acc[expense.description] = (acc[expense.description] || 0) + expense.amount;
            return acc;
          }, {});

          const labels = Object.keys(descriptionTotals);
          const data = Object.values(descriptionTotals);

          const ctx = expenseChartRef.current.getContext('2d');

          if (window.myExpenseChart) {
            window.myExpenseChart.destroy();
          }

          window.myExpenseChart = new Chart(ctx, {
            type: 'pie',
            data: {
              labels: labels,
              datasets: [
                {
                  label: 'Expenses by Description',
                  data: data,
                  backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                  ],
                  borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                  ],
                  borderWidth: 1,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
            },
          });
        }

        // Income Chart
        const incomeTransactions = transactions.filter(t => t.type === 'income');
        if (incomeTransactions.length > 0) {
          const descriptionTotals = incomeTransactions.reduce((acc, income) => {
            acc[income.description] = (acc[income.description] || 0) + income.amount;
            return acc;
          }, {});

          const labels = Object.keys(descriptionTotals);
          const data = Object.values(descriptionTotals);

          const ctx = incomeChartRef.current.getContext('2d');

          if (window.myIncomeChart) {
            window.myIncomeChart.destroy();
          }

          window.myIncomeChart = new Chart(ctx, {
            type: 'pie',
            data: {
              labels: labels,
              datasets: [
                {
                  label: 'Income by Description',
                  data: data,
                  backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                  ],
                  borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                  ],
                  borderWidth: 1,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
            },
          });
        }

        // Debt Chart
        const debtTransactions = transactions.filter(t => t.type === 'debt');
        if (debtTransactions.length > 0) {
          const lenderTotals = debtTransactions.reduce((acc, debt) => {
            acc[debt.lender] = (acc[debt.lender] || 0) + debt.amount;
            return acc;
          }, {});

          const labels = Object.keys(lenderTotals);
          const data = Object.values(lenderTotals);

          const ctx = debtChartRef.current.getContext('2d');

          if (window.myDebtChart) {
            window.myDebtChart.destroy();
          }

          window.myDebtChart = new Chart(ctx, {
            type: 'pie',
            data: {
              labels: labels,
              datasets: [
                {
                  label: 'Debts by Lender',
                  data: data,
                  backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                  ],
                  borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                  ],
                  borderWidth: 1,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
            },
          });
        }

        // Lend Chart
        const lendTransactions = transactions.filter(t => t.type === 'lend');
        if (lendTransactions.length > 0) {
          const lenderTotals = lendTransactions.reduce((acc, lend) => {
            acc[lend.lender] = (acc[lend.lender] || 0) + lend.amount;
            return acc;
          }, {});

          const labels = Object.keys(lenderTotals);
          const data = Object.values(lenderTotals);

          const ctx = lendChartRef.current.getContext('2d');

          if (window.myLendChart) {
            window.myLendChart.destroy();
          }

          window.myLendChart = new Chart(ctx, {
            type: 'pie',
            data: {
              labels: labels,
              datasets: [
                {
                  label: 'Lends by Debtor',
                  data: data,
                  backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                  ],
                  borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                  ],
                  borderWidth: 1,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
            },
          });
        }
      }, [expenses, transactions]);

      const calculateTotalDebt = () => {
        return transactions
          .filter(t => t.type === 'debt')
          .reduce((sum, t) => sum + t.amount, 0);
      };

      const calculateTotalLend = () => {
        return transactions
          .filter(t => t.type === 'lend')
          .reduce((sum, t) => sum + t.amount, 0);
      };

      return (
        <div className="dashboard" style={{display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around'}}>
          <div style={{maxWidth: '400px', margin: '20px auto'}}>
            <h2>Expense Dashboard</h2>
            {expenses.length === 0 ? (
              <p>No expenses added yet.</p>
            ) : (
              <div className="chart-container" style={{height: '300px'}}>
                <canvas ref={expenseChartRef}></canvas>
              </div>
            )}
          </div>
          <div style={{maxWidth: '400px', margin: '20px auto'}}>
            <h2>Income Dashboard</h2>
            <div className="chart-container" style={{height: '300px'}}>
              <canvas ref={incomeChartRef}></canvas>
            </div>
          </div>
          <div style={{maxWidth: '400px', margin: '20px auto'}}>
            <h2>Debt Dashboard</h2>
            <div className="chart-container" style={{height: '300px'}}>
              <canvas ref={debtChartRef}></canvas>
            </div>
            {transactions.filter(t => t.type === 'debt').length > 0 && (
              <ul style={{marginTop: '10px'}}>
                {Object.entries(transactions.filter(t => t.type === 'debt').reduce((acc, debt) => {
                  acc[debt.lender] = (acc[debt.lender] || 0) + debt.amount;
                  return acc;
                }, {})).map(([lender, amount]) => (
                  <li key={lender}>
                    {lender}: {formatIndianNumber(amount)}
                  </li>
                ))}
              </ul>
            )}
            <h3 style={{marginTop: '10px'}}>Total Debt: {formatIndianNumber(calculateTotalDebt())}</h3>
          </div>
          <div style={{maxWidth: '400px', margin: '20px auto'}}>
            <h2>Lend Dashboard</h2>
            <div className="chart-container" style={{height: '300px'}}>
              <canvas ref={lendChartRef}></canvas>
            </div>
            {transactions.filter(t => t.type === 'lend').length > 0 && (
              <ul style={{marginTop: '10px'}}>
                {Object.entries(transactions.filter(t => t.type === 'lend').reduce((acc, lend) => {
                  acc[lend.lender] = (acc[lend.lender] || 0) + lend.amount;
                  return acc;
                }, {})).map(([lender, amount]) => (
                  <li key={lender}>
                    {lender}: {formatIndianNumber(amount)}
                  </li>
                ))}
              </ul>
            )}
            <h3 style={{marginTop: '10px'}}>Total Lend: {formatIndianNumber(calculateTotalLend())}</h3>
          </div>
        </div>
      );
    }

    export default Dashboard;
