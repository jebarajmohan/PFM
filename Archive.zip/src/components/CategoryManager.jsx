import React, { useState, useMemo, useRef, useEffect } from 'react';

    function CategoryManager({ addCategory, categories }) {
      const [showCategories, setShowCategories] = useState(true);
      const [newCategory, setNewCategory] = useState('');
      const [type, setType] = useState('expense');

      const handleSubmit = (e) => {
        if (editCategoryIndex !== null) {
          handleUpdateCategory();
          return
        }
        e.preventDefault();
        if (newCategory && type === 'expense' && !categories.expense.includes(newCategory.trim())) {
          addCategory(newCategory.trim(), type);
          setNewCategory('');
          setShowCategories(true);
        }
        if (newCategory && type === 'income' && !categories.income.includes(newCategory.trim())) {
          addCategory(newCategory.trim(), type);
          setNewCategory('');
          setShowCategories(true);
        }
      };

      const [editCategoryIndex, setEditCategoryIndex] = useState(null);
      useEffect(() => {
        if (editCategoryIndex !== null) {
          setNewCategory(editCategoryName);
        }
      }, [editCategoryIndex])
      const [editCategoryName, setEditCategoryName] = useState('');
      const editCategoryRef = useRef(null);

      const handleEditCategory = (index) => {
        const categoryToEdit = type === 'expense' ? sortedExpenseCategories[index] : sortedIncomeCategories[index];
        setEditCategoryIndex(index);
        setEditCategoryName(categoryToEdit);
        setNewCategory(categoryToEdit);
        if (editCategoryRef.current) {
          editCategoryRef.current.focus();
        }
      };

      const handleUpdateCategory = () => {
        if (editCategoryIndex !== null && editCategoryName && editCategoryName.trim() !== '') {
          const updatedCategories = type === 'expense' ? [...categories.expense] : [...categories.income];
          updatedCategories[editCategoryIndex] = editCategoryName;
          if (type === 'expense') {
            localStorage.setItem('expenseCategories', JSON.stringify(updatedCategories));
            categories.expense = updatedCategories;
            
          } else {
            localStorage.setItem('incomeCategories', JSON.stringify(updatedCategories));
            categories.income = updatedCategories;
          }
          setEditCategoryIndex(null);
          setNewCategory('');
          setEditCategoryName('');
        }
      };

      const handleDeleteCategory = (index) => {
        const categoryToDelete = type === 'expense' ? sortedExpenseCategories[index] : sortedIncomeCategories[index];
        const isCategoryInUse = transactions.some(transaction => transaction.category === categoryToDelete);

        if (isCategoryInUse) {
          alert(`Cannot delete category "${categoryToDelete}" as it is used in transactions.`);
          return;
        }

        const confirmDelete = window.confirm(`Are you sure you want to delete category "${categoryToDelete}"?`);
        if (confirmDelete) {
          const updatedCategories = type === 'expense' ? [...categories.expense] : [...categories.income];
          updatedCategories.splice(index, 1);
          if (type === 'expense') {
            localStorage.setItem('expenseCategories', JSON.stringify(updatedCategories));
            categories.expense = updatedCategories;
            
          } else {
            localStorage.setItem('incomeCategories', JSON.stringify(updatedCategories));
            categories.income = updatedCategories;
            
          }
          if(type === 'expense') setExpenseCategories(updatedCategories)
          if(type === 'income') setIncomeCategories(updatedCategories)
          setShowCategories(true)
        }
      };

      const sortedExpenseCategories = useMemo(() => {
        return [...categories.expense].sort();
      }, [categories.expense]);

      const sortedIncomeCategories = useMemo(() => {
        return [...categories.income].sort();
      }, [categories.income]);

      const [expenseCategories, setExpenseCategories] = useState(() => {
        const saved = localStorage.getItem('expenseCategories');
        return saved ? JSON.parse(saved) : ['Food', 'Transportation', 'Utilities'];
      });

      const [incomeCategories, setIncomeCategories] = useState(() => {
        const saved = localStorage.getItem('incomeCategories');
        return saved ? JSON.parse(saved) : ['Salary', 'Freelance', 'Other'];
      }, [categories.income]);

      const [transactions, setTransactions] = useState(() => {
        const saved = localStorage.getItem('transactions');
        return saved ? JSON.parse(saved) : [];
      }, [categories.income]);

      return (
        <div style={{ display: 'flex', gap: '20px'}}>
          <div style={{ flex: 1 }}>
            <section style={{ marginBottom: '20px', border: '1px solid #d8dde6', borderRadius: '4px', padding: '15px' }}>
              <h2>Manage Categories</h2>
              <form onSubmit={handleSubmit}>
                <div className="input-group">
                  <label>Type</label>
                  <div className="radio-group">
                    <label>
                      <input
                        type="radio"
                        value="expense"
                        checked={type === 'expense'}
                        onChange={() => {
                          setType('expense')
                          setShowCategories(true)
                        }}
                        onClick={() => {
                          setShowCategories(true);
                        }}
                      />
                      Expense
                    </label>
                    <label>
                      <input
                        type="radio"
                        value="income"
                        checked={type === 'income'}
                        onChange={() => {
                          setType('income')
                          setShowCategories(true)
                        }}
                        onClick={() => {
                          setShowCategories(true);
                        }}
                      />
                      Income
                    </label>
                  </div>
                </div>
                <div className="input-group">
                  <label>New Category</label>
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    ref={editCategoryRef}
                    required
                  />
                </div>
                <button type="submit">Add Category</button>
              </form>
            </section>
          </div>
          {showCategories && (
            <section style={{ flex: 1, border: '1px solid #d8dde6', borderRadius: '4px', padding: '15px' }}>
            <h2 style={{marginBottom: '10px'}}>Current Categories</h2>
            <ul>
              {(type === 'expense' ? sortedExpenseCategories : sortedIncomeCategories)?.map((category, index) => (
                <li key={category} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', textDecoration: transactions.some(transaction => transaction.category === category) ? 'line-through' : 'none'}}>
                  {editCategoryIndex === index ? (
                    <input type="text" value={editCategoryName} onChange={(e) => setEditCategoryName(e.target.value)} />
                  ) : (
                    <span>{category}</span>
                  )}
                  <div><button onClick={() => handleEditCategory(index)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2em' }} title="Edit">✏️</button><button onClick={() => handleDeleteCategory(index)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2em' }} title="Delete">🗑️</button></div>
                </li>
              ))}
            </ul>
          </section>
          )}
        </div>
      );
    }

    export default CategoryManager;
